source("global.R")
source("control.R")

# Title and Dashboard -------------------------------------

# Header for the Shiny App 
dashboardPage(skin="purple",
  dashboardHeader(title = my_title),

  # Set up the side-bar for the Dashboard 
  dashboardSidebar(
    sidebarMenu(
      menuItem("Home", tabName = "home", icon = icon("dashboard"), selected = TRUE),
      menuItem(g1_title, tabName = "graph1", icon = icon("line-chart")),
      menuItem(g2_title, tabName = "graph2", icon = icon("tv")),
      menuItem(g3_title, tabName = "graph3", icon = icon("cloud"))
    )
  ),
  
  # Body of User Interface -----------------------------------
  dashboardBody(
      
    tabItems(

   tabItem(tabName="home",
        fluidRow(
            box(solidHeader = TRUE, width=12,
           title=h2("Welcome to", my_website, "."),
           p(strong(my_website), "is a tool for", my_website_description, "."),
           p("Navigate the tabs to the left."),
           h3("Meet", pic_name),
               img(src=pic_path, align="left", width=400)
           )),
           
        fluidRow(
#        box(width=12, status="warning",
            box(width=12,
           h4(pic_description)
           
            )
        )
),

##############
# Graph 1
tabItem(tabName="graph1",
        
        fluidRow(
          box( width = 12,  title=h2("Relationship between Height and Shoe Size"), 
              solidHeader = TRUE, background = "green",
              column(3, 
              radioButtons("radio_shoes", label = "Choose Data Set", 
                           choices = list("Random" = 1, "Millennials" = 2, "Coding for Girls" = 3), selected = 3),
              radioButtons("radio_sex", label = "Split on Group", 
                           choices = list("None" = 1, "Gender" = 2), selected = 1),
              
              radioButtons("radio_smoother", label = "Trend Line", choices = list("None" = 1, "Linear" = 2, "Smoother" = 3), 
                           selected = 1),
              sliderInput("span", label = "Span for Smoother", min = .1, max = 1, value = .4, step = .05)
              ),
          
              column(9,
              plotOutput("heightshoe")
              )
              )
              
        )
        ),
########### Graph 2
# TV, Color, and Age

tabItem(tabName = "graph2",
        fluidRow(
          box(background = "maroon", width = 12, title = h2(g2_title), solidHeader = TRUE,
              column(3, 
                     radioButtons("radio_ds2", label = "Choose Data Set", 
                                  choices = list("Millennials" = 1, "Coding for Girls" = 2), selected = 1),
                     radioButtons("radio_g", label = "Graph Types", 
                                  choices = list("Age" = 1, "Color" = 2, "TV" = 3, "TV and Color" = 4), 
                                  selected = 1),
                     sliderInput("bw", label = "Number of Bins for Histograms", min = 2, max = 10, value = 4, step = 1)
              ),
              
              column(9,
                     plotOutput("tac"))
                     
          )
        )
),
        
        

tabItem(tabName = "graph3",
        fluidRow(
          box(background = "fuchsia", width = 12, title = h2(g3_title), solidHeader = TRUE,
              column(3, 
                     radioButtons("radio_ds", label = "Choose Data Set", 
                                  choices = list("Millennials" = 1, "Coding for Girls" = 2), selected = 1),
                     radioButtons("radio_sub", label = "Subject", 
                                  choices = list("Activities" = 1, "Descriptions" = 2), selected = 1),
                     radioButtons("radio_sex3", label = "Split on Group", 
                                  choices = list("Both" = 1, "Female" = 2, "Male" = 3), selected = 1),
                     sliderInput("nwords", label = "Number of Words", min = 1, max = 10, value = 3, step = 1)
              ),
              
              column(9,
                     plotOutput("wc"))
        )
        
)
)
)))