source("global.R")

server <- function(input, output) {
  
  # Graph 1
  # Height and shoe size
  output$heightshoe <- renderPlot({
    
    if(input$radio_shoes == 1){
      df <- global_df
    } else if(input$radio_shoes == 2){
      df <- m_df
    }else {
      df <- c_df
    }
      
      g <- ggplot(data = df, aes( x= height, y = shoe_size)) + geom_point() + ggtitle("Height and Shoe Size") + 
        labs(x = "Height (in.)",  y = "Shoe Size (US)") + theme_light()
      
      if (input$radio_sex == 2){
        colScale <- scale_colour_manual(name = "Gender", values = palette_cols)
        g <- ggplot(data = df, aes( x= height, y = shoe_size,  colour = Gender)) + geom_point() + ggtitle("Height and Shoe Size") + 
          colScale + 
          labs(x = "Height (in.)",  y = "Shoe Size (US)") + theme_light() 
      }
      
      if (input$radio_smoother == 2){
        g <- g + stat_smooth(method = "lm")
      } else if (input$radio_smoother == 3){
        g <- g + stat_smooth(span = input$span)
      }
       
      print(g)
      
})
  
  
  # Graph 2
  # TV, Age, and Color
  output$tac <- renderPlot({
    
    if( input$radio_ds2 == 1){ # Millennials vs. CoG
      df <- m_df
    } else {
      df <- c_df
    }
    
    if (input$radio_g == 1){ # Age
      q <- ggplot(data = df, aes(x = Age)) + geom_histogram(bins = input$bw, fill = "hotpink4", colour = "black") + 
        labs(x = "Age (years)", y = "Frequency") + ggtitle("Histogram of Age") + theme_light()
    } else if (input$radio_g == 2) { # Color
      df$cols <- factor(df$FColor, levels = c("Red", "Orange", "Yellow", "Green",
                                            "Blue", "Indigo", "Violet", "Black",
                                            "White", "Brown", "Gray", "Teal",
                                            "Pink", "Gold"))
      gcols <- fcols[levels(df$cols) %in% df$cols]
      gcols <- gcols[!is.na(gcols)]
      q <- ggplot(data = df, aes(x = factor(1), fill = cols)) + geom_bar(width = 1) + coord_polar(theta = "y") + 
        scale_fill_manual(values = gcols, guide = FALSE) + theme_void() + ggtitle("\n Pie Chart of Favorite Colors")
      
    } else if (input$radio_g == 3){ # TV
      q <- ggplot(data = df, aes(x = TV)) + geom_bar() + theme_light() + theme(axis.text.x = element_text(angle = 90)) 
    } else if (input$radio_g == 4){ # TV and color}
      q <- ggplot(data = df, aes( x = FColor, fill = TV)) + geom_bar() + theme_light() + labs(x = "Favorite Color", y = "Frequency" )+
        ggtitle("Favorite Color and TV")
    }
    print(q)
    
  })
  
  
  # Graph 3
  # Word cloud
  output$wc <- renderPlot({
    if (input$radio_ds == 1)
      cp_o <- mill_wc
    else {
      cp_o <- cog_wc
    }
    if(input$radio_sex3 == 1 & input$radio_sub == 1){ #activities/both
      cp <- cp_o$mactb
    } else if( input$radio_sub == 1 & input$radio_sex3 == 2){ #activities/female)
      cp <- cp_o$mactf
    } else if( input$radio_sub == 1 & input$radio_sex3 == 3){ #activities/male)
      cp <- cp_o$mactm
    } else if( input$radio_sub == 2 & input$radio_sex3 == 1){ #descriptions/both)
      cp <- cp_o$mdesb
    } else if( input$radio_sub == 2 & input$radio_sex3 == 2){ #descriptions/female)
      cp <- cp_o$mdesf
    } else if( input$radio_sub == 2 & input$radio_sex3 == 3){ #descriptions/male)
      cp <- cp_o$mdesm
    } 
    print(wordcloud(cp, max.words = input$nwords))
  })


    
}
