# Preliminary files to run before running the Shiny App

# Package names
pkgs <- c("shiny", "shinydashboard", "ggplot2", "plyr", "tm", "wordcloud", "reshape2", "RColorBrewer")

# Install packages if not already installed
new.packages <- pkgs[!(pkgs %in% installed.packages()[,"Package"])]
if(length(new.packages)) install.packages(new.packages)
