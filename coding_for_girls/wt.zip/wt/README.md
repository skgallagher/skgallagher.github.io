# MIDAS Hack-a-thon Repository 
This repository is the home for our MIDAS Mission Public Health Hack-a-Thon. Our final visualization can be viewed at the following link:

http://stat.cmu.edu:3838/sgallagh/hackathon/