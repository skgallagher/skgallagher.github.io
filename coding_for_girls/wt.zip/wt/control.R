# File to change for WT presentation

# Change the text inside the quotes!

##################################
# Basics
my_title <- "Coding for Girls"

my_website <- "Exploring Data Analysis"

my_website_description <- "analyzing and visualizing data"
#########################################

#########################
# Picture
# Insert your own picture here!
pic_path <- "bailee.jpg"

pic_name <- "Bailee"

pic_description <- "Bailee is a dog who loves tennis balls and coding"
##############################################

###############################
# Graph 1
g1_title <- "Height and Shoe Size"

# Colors for Female then Male
# Change the colors below
# Possible colors for R found here:  http://research.stowers-institute.org/efg/R/Color/Chart/ColorChart.pdf
palette_cols <- c("orange", "purple")

#####################################

###############################
# Graph 2
g2_title <- "Age, TV, and Color"

#####################################

###############################
# Graph 3
g3_title <- "Word Cloud"

#####################################