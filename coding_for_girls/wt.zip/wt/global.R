# Libraries -------------
library(shiny)
library(shinydashboard)
library(plyr)
library(ggplot2)
library(reshape2)
library(RColorBrewer)
library(wordcloud)
library(Cairo)
options(shiny.usecairo=TRUE) 


### Fabricated Data
set.seed(42)
n <- 100
shoe_size <- round(rnorm(n, 7, 2), 1)
height <- rnorm(n, 59, 3)
gender <- sample(c("F", "M"), n, replace = T)

global_df <- data.frame(height = height, shoe_size = shoe_size, Gender = gender)


# Millennial data
m_df <- read.csv("data/millennial.csv")
colnames(m_df) <- c("Timestamp", "Gender", "Age", "height", "shoe_size", "TV", "FColor", "adj", "act")

# Coding for Girls data
c_df <- read.csv("data/cog.csv")
colnames(c_df) <- c("Timestamp", "Gender", "Age", "height", "shoe_size", "TV", "FColor", "adj", "act")



# Word clouds
mill_wc <- readRDS("data/mill_wc.Rda")
cog_wc <- readRDS("data/cog_wc.Rda")


# Favorite colors
fcols <- c("red", "orange", "yellow", "darkgreen", "blue", "mediumpurple3", "purple", 
           "black", "white", "brown", "gray", "darkcyan", "pink", "gold")


