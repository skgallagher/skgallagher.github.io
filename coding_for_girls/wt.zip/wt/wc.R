# Millennial Word cloud

library(tm)
library(wordcloud)
library(SnowballC)

source("global.R")

makeCorpus <- function(words){
  m_act <- Corpus(VectorSource(words))
  m_act <- tm_map(m_act, removePunctuation)
  m_act <- tm_map(m_act, removeWords, stopwords('english'))
  return(m_act)
}

#millennial activities both
mactb <- makeCorpus(m_df$act)
mactf <- makeCorpus(m_df$act[m_df$Gender == "Female"])
mactm <- makeCorpus(m_df$act[m_df$Gender == "Male"])

# Millennial descriptions
#millennial activities both
mdesb <- makeCorpus(m_df$adj)
mdesf <- makeCorpus(m_df$adj[m_df$Gender == "Female"])
mdesm <- makeCorpus(m_df$adj[m_df$Gender == "Male"])
wordcloud(mdesb, max.words = 10)


m_cll <- list(mactb = mactb, mactf = mactf, mactm = mactm, mdesb = mdesb, mdesf = mdesf, mdesm = mdesm)
saveRDS(m_cll, file = "data/mill_wc.Rda")

# Girls Word Cloud

# cog activities both
mactb <- makeCorpus(c_df$act)
mactf <- makeCorpus(c_df$act[c_df$Gender == "Female"])
mactm <- makeCorpus(c_df$act[c_df$Gender == "Male"])

# cog descriptions
# cog activities both
mdesb <- makeCorpus(c_df$adj)
mdesf <- makeCorpus(c_df$adj[c_df$Gender == "Female"])
mdesm <- makeCorpus(c_df$adj[c_df$Gender == "Male"])
wordcloud(mdesb, max.words = 10)


c_cll <- list(mactb = mactb, mactf = mactf, mactm = mactm, mdesb = mdesb, mdesf = mdesf, mdesm = mdesm)
saveRDS(c_cll, file = "data/cog_wc.Rda")
